# -*- coding: utf-8 -*-
# AWS RDS MySQL
# @author =__Uluç Furkan Vardar__

import pymysql
import json 
REGION="us-east-2a"
rds_host = "nightclubproject.cdukbpxo4e76.us-east-2.rds.amazonaws.com"
name = "master"
password = "password"
db_name = "innodb"
"""

PROCEDURE `addEventNight`( artistName varchar(60)  , artistPrice DOUBLE , eventType varchar(40),
                                                eventDate varchar(30) , eventComment varchar(1000), totalProfit double, 
                                                totalEndersement double, tip double, dontpay double, totalCost double, 
                                                nameOfSales varchar(200), sumOfProfit varchar(200), sumOfGiro varchar(200),
                                                salesNumber varchar(200), cl70Number int ,cl35Number int, confetyNumber int ,
                                                bottleNumber int ,totalDiscount double, alcoholIndex double, generalIndex double, grupEnterenceFree double)

"""

def insert2DB(artistName, artistPrice, eventType, eventDate, eventComment, totalProfit, totalEndersement, tip,
                dontPay, totalCost, nameOfSales, sumOfProfit, sumOfGiro, salesNumber, cl70Number,
                cl35Number, confetyNumber, bottleNumber, totalDiscount, alcoholIndex, generalIndex,
                grupEnterenceFree):
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
    try:
        forms = []
        with conn.cursor() as cur:
            cur.execute("""call innodb.addEventNight  ("%s",%s,"%s","%s","%s",%s,%s,%s,%s,%s,"%s","%s","%s","%s",%s,%s,%s,%s,%s,%s,%s);                                                        
                                    """%(artistName,artistPrice,eventType,eventDate,eventComment,totalProfit,totalEndersement,tip,
                                        dontPay,totalCost,nameOfSales,sumOfProfit,sumOfGiro,salesNumber,cl70Number,
                                        cl35Number,confetyNumber,bottleNumber,totalDiscount,alcoholIndex,generalIndex,
                                        grupEnterenceFree))
            conn.commit()
            cur.close()        
        return true
    except Exception as e:
        print(str(e))
        return False
    cur.close()

def main(event, context):
    return listForms(event['artistName'],event['artistPrice'],event['eventType'],event['eventComment'],event['totalProfit'],
                    event['totalEndersement'],event['tip'],event['dontPay'],event['totalCost'],event['nameOfSales'],
                    event['sumOfProfit'],event['sumOfGiro'],event['salesNumber'],event['cl70Number'],event['cl35Number'],
                    event['confetyNumber'],event['bottleNumber'],event['totalDiscount'],
                    event['alcoholIndex'],event['generalIndex'],event['grupEnterenceFree'] )
       



